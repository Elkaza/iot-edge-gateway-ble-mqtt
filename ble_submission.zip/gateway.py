#!/usr/bin/env python3
import os
import sys
from datetime import datetime, timezone

from pydbus import SystemBus
from gi.repository import GLib

BLUEZ = "org.bluez"

OM_IFACE = "org.freedesktop.DBus.ObjectManager"
PROPS_IFACE = "org.freedesktop.DBus.Properties"

ADAPTER_IFACE = "org.bluez.Adapter1"
DEV_IFACE = "org.bluez.Device1"
CHRC_IFACE = "org.bluez.GattCharacteristic1"

# Nordic UART UUIDs
NUS_SERVICE_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e"
# In your bluetoothctl output, notifications came from UUID 6e400003...
NUS_NOTIFY_UUID = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"  # notify characteristic
NUS_WRITE_UUID  = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"  # write characteristic (not required for this task)

def now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def mac_to_dev_path(mac: str) -> str:
    return "/org/bluez/hci0/dev_" + mac.strip().upper().replace(":", "_")

def bytes_to_text(v):
    try:
        return bytes(v).decode("utf-8", errors="replace").strip()
    except Exception:
        return str(list(v))

def get_managed_objects(bus):
    # BlueZ exports ObjectManager at "/"
    m = bus.get(BLUEZ, "/")
    return m.GetManagedObjects()

def find_adapter_path(objects):
    for path, ifaces in objects.items():
        if ADAPTER_IFACE in ifaces:
            return path
    return None

def find_device_path(objects, mac):
    target = mac_to_dev_path(mac)
    if target in objects:
        return target
    # fallback: search by Address property
    mac_l = mac.strip().lower()
    for path, ifaces in objects.items():
        d = ifaces.get(DEV_IFACE)
        if not d:
            continue
        if str(d.get("Address", "")).lower() == mac_l:
            return path
    return None

def start_discovery(bus, adapter_path):
    adapter = bus.get(BLUEZ, adapter_path)
    try:
        print(f"{now()} Starting discovery on {adapter_path} ...", flush=True)
        adapter.StartDiscovery()
    except Exception as e:
        print(f"{now()} Discovery start failed (can be ok): {e}", flush=True)

def wait_for_device(bus, mac, timeout_s=10):
    deadline = GLib.get_monotonic_time() + int(timeout_s * 1_000_000)
    while GLib.get_monotonic_time() < deadline:
        objects = get_managed_objects(bus)
        dev_path = find_device_path(objects, mac)
        if dev_path:
            return dev_path, objects
        GLib.usleep(300_000)
    return None, None

def connect_with_retries(dev, tries=3):
    # dev is a proxy for /org/bluez/... Device1 object
    for i in range(1, tries + 1):
        try:
            print(f"{now()} Connecting (attempt {i}/{tries})...", flush=True)
            dev.Connect()
            return
        except Exception as e:
            print(f"{now()} Connect error: {e}", flush=True)
            GLib.usleep(800_000)

def wait_services_resolved(dev, timeout_s=12):
    # poll Device1.ServicesResolved via org.freedesktop.DBus.Properties.Get
    deadline = GLib.get_monotonic_time() + int(timeout_s * 1_000_000)
    while GLib.get_monotonic_time() < deadline:
        try:
            resolved = bool(dev.Get(DEV_IFACE, "ServicesResolved"))
            if resolved:
                return True
        except Exception:
            pass
        GLib.usleep(400_000)
    return False

def find_notify_char(objects, dev_path):
    # Prefer the NUS notify UUID, otherwise any characteristic that supports notify/indicate
    best = None
    any_notify = None

    for path, ifaces in objects.items():
        if not path.startswith(dev_path + "/"):
            continue
        ch = ifaces.get(CHRC_IFACE)
        if not ch:
            continue

        uuid = str(ch.get("UUID", "")).lower()
        flags = set(ch.get("Flags", []))

        # Best: exact NUS notify UUID (even if flags not present)
        if uuid == NUS_NOTIFY_UUID:
            best = path

        # Fallback: anything with notify/indicate
        if any_notify is None and (("notify" in flags) or ("indicate" in flags)):
            any_notify = path

    return best or any_notify

def main():
    mac = os.environ.get("SENSOR_MAC", "").strip()
    if not mac:
        print("ERROR: SENSOR_MAC not set", file=sys.stderr)
        sys.exit(2)

    bus = SystemBus()

    objects = get_managed_objects(bus)
    adapter_path = find_adapter_path(objects)
    if not adapter_path:
        print("ERROR: No Bluetooth adapter found on DBus.", file=sys.stderr)
        sys.exit(10)

    # Ensure device exists in BlueZ (discover if needed)
    dev_path, objects = wait_for_device(bus, mac, timeout_s=2)
    if not dev_path:
        start_discovery(bus, adapter_path)
        dev_path, objects = wait_for_device(bus, mac, timeout_s=10)

    if not dev_path:
        print(f"ERROR: BLE device {mac} not found on DBus (not discovered).", file=sys.stderr)
        sys.exit(3)

    print(f"{now()} Found device at {dev_path}", flush=True)
    dev = bus.get(BLUEZ, dev_path)

    # Try to connect (if already connected, this can error — that’s fine)
    connect_with_retries(dev, tries=3)

    # Wait until services are resolved; otherwise GATT objects may not appear
    if not wait_services_resolved(dev, timeout_s=15):
        print("ERROR: Services not resolved (timeout). "
              "Close bluetoothctl, ensure nothing else is connected, then restart bluetooth.",
              file=sys.stderr)
        sys.exit(4)

    # Now re-read managed objects and find notify characteristic
    objects = get_managed_objects(bus)
    char_path = find_notify_char(objects, dev_path)
    if not char_path:
        print("ERROR: No notify characteristic found under the device.", file=sys.stderr)
        sys.exit(5)

    print(f"{now()} Using notify characteristic: {char_path}", flush=True)
    ch = bus.get(BLUEZ, char_path)

    def on_props_changed(sender, object, iface, signal, params):
        # params is (interface_name, changed_dict, invalidated_list)
        iface_name, changed, _invalidated = params
        if iface_name != CHRC_IFACE:
            return
        if "Value" not in changed:
            return
        text = bytes_to_text(changed["Value"])
        print(f"{now()}  {text}", flush=True)

    # Subscribe to PropertiesChanged for this characteristic
    bus.subscribe(
        iface=PROPS_IFACE,
        signal="PropertiesChanged",
        object=char_path,
        signal_fired=on_props_changed,
    )

    # Start notifications
    try:
        ch.StartNotify()
        print(f"{now()} Notify started", flush=True)
    except Exception as e:
        print(f"ERROR: StartNotify failed: {e}", file=sys.stderr)
        sys.exit(6)

    GLib.MainLoop().run()

if __name__ == "__main__":
    main()
